<?php

namespace Laravel\Roster\Enums;

enum Approaches: string
{
    case ACTION = 'action';
    case DDD = 'ddd';
}
