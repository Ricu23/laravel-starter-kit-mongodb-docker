## Inertia v1

- Inertia v1 does _not_ come with these features. Do not recommend using these Inertia v2 features directly.
    - Polling
    - Prefetching
    - Deferred props
    - Infinite scrolling using merging props and `WhenVisible`
    - Lazy loading data on scroll
