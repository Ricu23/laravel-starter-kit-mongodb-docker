<?php

namespace Illuminate\Container\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_PARAMETER)]
class DB extends Database
{
    //
}
