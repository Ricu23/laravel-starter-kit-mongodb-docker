<?php

declare(strict_types=1);

namespace Laravel\Mcp\Server\Contracts\Tools;

interface Annotation
{
    public function key(): string;
}
