<?php

declare(strict_types=1);

namespace Laravel\Mcp\Server\Contracts;

interface Errable
{
    //
}
