<?php declare(strict_types=1);

namespace Amp\Websocket;

use Amp\ByteStream\StreamException;

class WebsocketException extends StreamException
{
}
