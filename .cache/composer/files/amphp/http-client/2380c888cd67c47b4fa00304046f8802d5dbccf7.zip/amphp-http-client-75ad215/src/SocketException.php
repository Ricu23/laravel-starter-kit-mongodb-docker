<?php declare(strict_types=1);

namespace Amp\Http\Client;

class SocketException extends HttpException
{
}
