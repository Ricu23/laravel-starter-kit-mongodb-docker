<?php declare(strict_types=1);

namespace Amp\Http;

final class HPackException extends \Exception
{
}
