<?php

declare(strict_types=1);

use Pest\Browser\Browsable;
use Pest\Plugin;

Plugin::uses(Browsable::class);
