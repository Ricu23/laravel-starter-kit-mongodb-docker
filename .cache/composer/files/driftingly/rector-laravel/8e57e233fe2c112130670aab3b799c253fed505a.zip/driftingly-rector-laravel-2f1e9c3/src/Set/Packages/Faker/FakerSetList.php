<?php

namespace RectorLaravel\Set\Packages\Faker;

final class FakerSetList
{
    /**
     * @var string
     */
    public const FAKER_10 = __DIR__ . '/../../../../config/sets/packages/faker/faker-10.php';
}
