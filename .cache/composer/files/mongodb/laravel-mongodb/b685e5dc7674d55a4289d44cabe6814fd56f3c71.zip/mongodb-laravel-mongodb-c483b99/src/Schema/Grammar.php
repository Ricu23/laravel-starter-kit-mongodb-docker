<?php

declare(strict_types=1);

namespace MongoDB\Laravel\Schema;

use Illuminate\Database\Schema\Grammars\Grammar as BaseGrammar;

class Grammar extends BaseGrammar
{
}
